Select * From "Account Balance";
Select * From "Appointment";
Select * From "Customer";
Select * From "Employee";
Select * From "Invoice";
Select * From "No_Poop";
Select * From "PayStub";
Select * From "Payment";
Select * From "Payroll";
Select * From "Pet";
Select * From "Products";
Select * From "Service";


SELECT "Employee"."F_Name", "Employee"."L_Name", "PayStub"."Total_Pay"
FROM "Employee"
JOIN "PayStub" ON "Employee"."Employee_ID" = "PayStub"."Employee_ID";

SELECT "Customer"."F_Name", "Customer"."L_Name", "Invoice"."Total_Price"
FROM "Customer"
JOIN "Invoice" ON "Customer"."Customer_ID" = "Invoice"."Customer_ID";

SELECT "L_Name", SUM("Total_Price") FROM "Customer"
JOIN "Appointment" ON "Customer"."Customer_ID" = "Appointment"."Customer_ID"
JOIN "Invoice" ON "Customer"."Customer_ID" = "Invoice"."Customer_ID"
GROUP BY "Customer"."Customer_ID"
ORDER BY "Customer"."Customer_ID";

SELECT "Account Balance"."Amount", "Customer"."F_Name", "Customer"."L_Name", "Customer"."Address", "Customer"."Email"
FROM "Account Balance"
JOIN "Customer" ON "Account Balance"."Customer_ID" = "Customer"."Customer_ID"
ORDER BY "Account Balance"."Amount" DESC;

SELECT "Employee"."F_Name", "Employee"."L_Name", "Employee"."Address", "PayStub"."Num_Hr_Worked", "PayStub"."Week_Num", "PayStub"."Year", "Payroll"."Direct_Deposit", "Payroll"."Pay_Rate"
FROM "Employee"
JOIN "PayStub" ON "Employee"."Employee_ID" = "PayStub"."Employee_ID"
JOIN "Payroll" ON "PayStub"."Employee_ID" = "Payroll"."Employee_ID"
WHERE "Employee"."Employee_ID" = 1
ORDER BY "PayStub"."Year" DESC, "PayStub"."Week_Num" DESC


SELECT "Appointment"."Appt_ID", "Customer"."Customer_ID", "Appointment"."Appt_Date"
FROM "Appointment"
JOIN "Customer" ON "Appointment"."Customer_ID" = "Customer"."Customer_ID";

SELECT "PayStub"."Year", SUM("PayStub"."Total_Pay") FROM "PayStub"
GROUP BY "PayStub"."Year"
ORDER BY SUM("PayStub"."Total_Pay") DESC;

SELECT "Appointment"."Appt_Date", "Appointment"."Appt_Time", "Customer"."L_Name", "Customer"."Address", "Customer"."Phone_Num", "Customer"."WasteBinLocation", "Customer"."Email", "Employee"."F_Name"
FROM "Appointment"
JOIN "Customer" ON "Appointment"."Customer_ID" = "Customer"."Customer_ID"
JOIN "Employee" ON "Appointment"."Employee_ID" = "Employee"."Employee_ID"
WHERE "Appointment"."Appt_Date" = '2021-07-19'
ORDER BY "Appointment"."Appt_Time" ASC;
