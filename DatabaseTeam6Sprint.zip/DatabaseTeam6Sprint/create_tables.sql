CREATE TABLE "NoPoop" (
  "Facility_ID" serial,
  "Address" varChar(50),
  "Phone" varChar(10),
  "Email" varChar(50),
  PRIMARY KEY ("Facility_ID")
);

CREATE TABLE "Customer" (
  "Customer_ID" serial,
  "F_Name" varChar(50),
  "L_Name" varChar(50),
  "Address" varChar(50),
  "Phone_Num" varChar(10),
  "WasteBinLocation" varChar(50),
  "Email" varChar(50),
  PRIMARY KEY ("Customer_ID")
);

CREATE TABLE "Appointment" (
  "Appt_ID" serial,
  "Customer_ID" int,
  "Employee_ID" int,
  "Appt_Date" date,
  "Appt_Time" time,
  PRIMARY KEY ("Appt_ID"),
  CONSTRAINT "FK_Appointment.Customer_ID"
    FOREIGN KEY ("Customer_ID")
      REFERENCES "Customer"("Customer_ID")
);

CREATE TABLE "Pet" (
  "Pet_ID" serial,
  "Customer_ID" int,
  "Name" varChar(50),
  "Species" varChar(50),
  PRIMARY KEY ("Pet_ID"),
  CONSTRAINT "FK_Pet.Customer_ID"
    FOREIGN KEY ("Customer_ID")
      REFERENCES "Customer"("Customer_ID")
);

CREATE TABLE "Account Balance" (
  "Balance_ID" serial,
  "Customer_ID" int,
  "Date" date,
  "Amount" int,
  PRIMARY KEY ("Balance_ID")
);

CREATE TABLE "Products" (
  "Product_ID" serial,
  "Product_Name" varChar(50),
  "Product_Cost" int,
  PRIMARY KEY ("Product_ID")
);

CREATE TABLE "Payment" (
  "Payment_ID" serial,
  "Customer_ID" int,
  "Pay_Method" varChar(50),
  "Card_Num" int,
  "Expiry_Date" varChar(50),
  "Billing_Address" varChar(50),
  PRIMARY KEY ("Payment_ID"),
  CONSTRAINT "FK_Payment.Customer_ID"
    FOREIGN KEY ("Customer_ID")
      REFERENCES "Customer"("Customer_ID")
);

CREATE TABLE "Service" (
  "Service_ID" serial,
  "Service_Name" varChar(50),
  "Service_Price" int,
  PRIMARY KEY ("Service_ID")
);

CREATE TABLE "Invoice" (
  "Invoice_ID" serial,
  "Payment_ID" int,
  "Balance_ID" int,
  "Customer_ID" int,
  "Service_ID" int,
  "Product_ID" int,
  "DateOfService" varChar(50),
  "Total_Hours" int,
  "Total_Price" int,
  PRIMARY KEY ("Invoice_ID"),
  CONSTRAINT "FK_Invoice.Payment_ID"
    FOREIGN KEY ("Payment_ID")
      REFERENCES "Payment"("Payment_ID"),
  CONSTRAINT "FK_Invoice.Customer_ID"
    FOREIGN KEY ("Customer_ID")
      REFERENCES "Customer"("Customer_ID"),
  CONSTRAINT "FK_Invoice.Balance_ID"
    FOREIGN KEY ("Balance_ID")
      REFERENCES "Account Balance"("Balance_ID"),
  CONSTRAINT "FK_Invoice.Product_ID"
    FOREIGN KEY ("Product_ID")
      REFERENCES "Products"("Product_ID"),
  CONSTRAINT "FK_Invoice.Service_ID"
    FOREIGN KEY ("Service_ID")
      REFERENCES "Service"("Service_ID")
);

CREATE TABLE "Employee" (
  "Employee_ID" serial,
  "F_Name" varChar(50),
  "L_name" varChar(50),
  "Address" varChar(50),
  "Phone_Num" varChar(10),
  "Email" varChar(50),
  "Facility_ID" int,
  PRIMARY KEY ("Employee_ID"),
  CONSTRAINT "FK_Employee.Facility_ID"
    FOREIGN KEY ("Facility_ID")
      REFERENCES "No_Poop"("Facility_ID")
);

CREATE TABLE "Payroll" (
  "Payroll_ID" serial,
  "Employee_ID" int,
  "Direct_Deposit" varChar(50),
  "Pay_Rate" int,
  "Payment_Type" varChar(50),
  PRIMARY KEY ("Payroll_ID"),
  CONSTRAINT "FK_Payroll.Employee_ID"
    FOREIGN KEY ("Employee_ID")
      REFERENCES "Employee"("Employee_ID")
);

CREATE TABLE "PayStub" (
  "Employee_ID" serial,
  "Num_Hr_Worked" int,
  "Year" int,
  "Week_Num" int,
  "Total_Pay" int,
  PRIMARY KEY ("Employee_ID"),
  CONSTRAINT "FK_PayStub.Employee_ID"
    FOREIGN KEY ("Employee_ID")
      REFERENCES "Employee"("Employee_ID")  
);